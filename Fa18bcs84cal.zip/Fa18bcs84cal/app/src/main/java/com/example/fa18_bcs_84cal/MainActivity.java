package com.example.fa18_bcs_84cal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button myButton9;
    private Button myButton8;
    private Button myButton7;
    private Button myButton6;
    private Button myButton5;
    private Button myButton4;
    private Button myButton3;
    private Button myButton2;
    private Button myButton1;
    private Button myButton0;
    private Button myButtonDot;
    private Button myButtonPlus;
    private Button myButtonEqual;
    private Button myButtonMinus;
    private Button myButtonMultiply;
    private Button myButtonDivide;
    private Button myButtonOnOff;
    private TextView answer;

    @Override
    protected  void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myButton9 = findViewById(R.id.nine);
        myButton8 = findViewById(R.id.eight);
        myButton7 = findViewById(R.id.seven);
        myButton6 = findViewById(R.id.six);
        myButton5 = findViewById(R.id.five);
        myButton4 = findViewById(R.id.four);
        myButton3 = findViewById(R.id.three);
        myButton2 = findViewById(R.id.two);
        myButton1 = findViewById(R.id.one);
        myButtonPlus = findViewById(R.id.plus);
        myButtonMinus = findViewById(R.id.minus);
        myButtonMultiply = findViewById(R.id.multiply);
        myButtonDivide = findViewById(R.id.divide);
        myButtonEqual = findViewById(R.id.equal);
        myButtonDot = findViewById(R.id.dot);
        myButton0 = findViewById(R.id.zero);
        myButtonOnOff = findViewById(R.id.clear);
        answer = findViewById(R.id.res);


        myButtonOnOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText(" ");
            }
        });
        myButton9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("9");
            }
        });
        myButton8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("8");
            }
        });
        myButton7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("7");
            }
        });
        myButton6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("6");
            }
        });
        myButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("5");
            }
        });
        myButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("4");
            }
        });
        myButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("3");
            }
        });
        myButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("2");
            }
        });
        myButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("1");
            }
        });
        myButton0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("0");
            }
        });
        myButtonPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("+");
            }
        });
        myButtonMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("-");
            }
        });
        myButtonMultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("*");
            }
        });
        myButtonEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("=");
            }
        });
        myButtonDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("/");
            }
        });
        myButtonDot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText(".");
            }
        });
        answer = findViewById(R.id.res);
    }


    }
